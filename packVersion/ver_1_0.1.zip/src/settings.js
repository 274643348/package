window._CCSettings = {
    "platform": "android",
    "groupList": [
        "default"
    ],
    "collisionMatrix": [
        [
            true
        ]
    ],
    "rawAssets": {
        "assets": {
            "6aoKpq6+5BVaCIpoemqt7E": [
                "Texture/HelloWorld.png",
                "cc.Texture2D"
            ],
            "a8Anh32NZGRZegUtSgEj26": [
                "Texture/singleColor.png",
                "cc.Texture2D"
            ]
        }
    },
    "launchScene": "db://assets/Scene/helloworld.fire",
    "scenes": [
        {
            "url": "db://assets/Scene/helloworld.fire",
            "uuid": "2dL3kvpAxJu6GJ7RdqJG5J"
        }
    ],
    "packedAssets": {
        "05dd1dc0e": [
            "2dL3kvpAxJu6GJ7RdqJG5J",
            "31vIlawANFZqnzLlSuHBfc",
            "41D7kWhyFGY7q4NDlzkazn"
        ]
    },
    "orientation": "",
    "debug": true
};
